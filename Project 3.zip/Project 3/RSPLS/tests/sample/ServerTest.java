package sample;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.Socket;
import java.util.function.Consumer;
import java.net.InetAddress;

import static org.junit.jupiter.api.Assertions.*;

class ServerTest {

    Consumer<Serializable> test;
    Server testServer = new Server(test);

    @Test
    void getPort() {
        testServer.setPort(5);
        assertEquals(5, testServer.getPort(),"Port should be 5");
    }

    @Test
    void getActive() {
        assertFalse(testServer.getActive(), "The server should start off not active");
    }

    @Test
    void setActive() {
        testServer.turnOnServer();
        assertTrue(testServer.getActive(), "Server should now be active");
    }

    @Test
    void turnOnServer() {
        assertEquals(0, testServer.connectionList.size(), "We start with 0 connections");
    }

    @Test
    void turnOffServer() {
        assertFalse(testServer.getActive(),"We should have server as not active");
    }
}