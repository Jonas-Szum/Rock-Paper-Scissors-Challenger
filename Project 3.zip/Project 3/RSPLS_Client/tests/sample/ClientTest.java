package sample;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.Socket;
import java.util.function.Consumer;
import java.net.InetAddress;

import static org.junit.jupiter.api.Assertions.*;

class ClientTest {

    Consumer<Serializable> test;
    Client testClient = new Client(test);

    @Test
    void isValid() {
        testClient.setValid(true);
        assertEquals(true, testClient.isValid(), "Test should show valid");
    }

    @Test
    void getPort() {
        testClient.setPort(3);
        assertEquals(3, testClient.getPort(),"Issue with get port, should be 3");
    }

    @Test
    void getIP() throws Exception{
        byte[] testAddress = new byte[]{127, 0, 0, 1};
        InetAddress testIP = InetAddress.getByAddress(testAddress);
        testClient.setIP(testIP);
        assertEquals(testIP, testClient.getIP(),"IP Address set incorrectly");
    }

    @Test
    void startConnection() {
        assertNull(testClient.connection.s, "This should start off as null");
    }

    @Test
    void stopConnection() throws Exception{
        testClient.stopConnection();
        assertFalse(testClient.connected,"Connection should now be false");
    }
}